package com.privateproject.jetpacklearning.view

import android.view.View

interface DogClickListener {
    fun onDogClicked(v: View)
}